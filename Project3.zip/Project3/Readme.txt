npm init -y

npm i express mongoose ejs
==========================================================
mongod.exe 
mongo.exe
===========================index.js===============================
const express = require('express');
const mongoose = require('mongoose');
==========================================================
database folder -- db.js
\\
const mongoose = require("mongoose");

async function dbconnection() {
     var connection = await mongoose.connect(
       "mongodb://127.0.0.1:27017/userdetails"
     );
     return connection;
}

module.exports = dbconnection;
\\
=============================index.js==============================
const db = require('./database/db.js');

db();

var app = express();

app.use(express.json());

app.get('/add', function (req, res) {
    res.render('adduser.ejs');
})

app.get("/show", function (req, res) {
  res.render("showuser.ejs");
});

app.listen(8000);
=================================================================
create views folder

create 3 files --- adduser.ejs,showuser.js,menu.ejs

------menu.ejs----------
add bootstrap links from website...link and script
search for nav in bootstrap
 add navbar code from it into this file

 ----------adduser.ejs------------
 <%-include('menu')%>

 <div class="container">
    <h1>Add User</h1>
</div>

 ----------showuser.ejs------------
 <%-include('menu')%>

 <div class="container">
    <h1>Show User</h1>
</div>

===================================mongo=====================
db.newusers.insert({name:"Pankaja",email:"pankajasharma2@gmail.com",mobileNo : 8149406199})

db.newusers.insert({name:"Kajal",email:"kajal@gmail.com",mobileNo : 8653266762})

==========
app password

bfae deop zwbw vldr
======================================
to manage records through email

nodemailer lib----------
npm install nodemailer
--------------------------------
on top of the file in index.js

const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "maddison53@ethereal.email",
    pass: "jn7jnAPss4f63QBp6D",
  },
});

